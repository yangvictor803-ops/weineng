# 堆叠式电池

> https://www.saonon.com/microgrids/show_100000070249188.html

- 首页

- 发电机组

- 微电网

- 关于威能

- 成功案例

- 服务支持

- 联系威能

- 柴油发电机组

- 电气控制系统

- 租赁产品

- 开架型发电机组

- 静音型发电机组

- 集装箱发电机组

- 便携式小型发电机组

- 移动发电机组

- 低噪音电站

- 康明斯系列

![康明斯系列](https://www.saonon.com/vancheerfile/images/2019/3/20190320025217458.jpg)

- 铂金斯系列

![铂金斯系列](https://www.saonon.com/vancheerfile/images/2019/6/20190621113434651.png)

- 高压发电机组

![高压发电机组](https://www.saonon.com/vancheerfile/images/2019/6/20190628103953612.jpg)

- 玉柴系列

![玉柴系列](https://www.saonon.com/vancheerfile/images/2019/6/20190621112631964.png)

- 产品

- 解决方案

- 微电网系统

- 光储充系统

- 户用储能系统

- 一体化微电网系统

![一体化微电网系统](https://www.saonon.com/vancheerfile/images/2025/6/20250610101739852.jpg)

- 20尺集装箱储能系统

![20尺集装箱储能系统](https://www.saonon.com/vancheerfile/images/2024/7/20240709152545371.jpg)

- 10尺集装箱储能系统

![10尺集装箱储能系统](https://www.saonon.com/vancheerfile/images/2024/7/20240709152733980.jpg)

- 户外柜工商业储能系统

![户外柜工商业储能系统](https://www.saonon.com/vancheerfile/images/2024/7/2024070915295871.jpg)

- CMS综合管理系统

![CMS综合管理系统](https://www.saonon.com/vancheerfile/images/2024/7/2024070915307572.jpg)

- 风力发电机

![风力发电机](https://www.saonon.com/vancheerfile/images/2023/7/20230707094420776.jpg)

- 智能光伏逆变器

![智能光伏逆变器](https://www.saonon.com/vancheerfile/images/2024/7/20240709154021479.jpg)

- 高性能太阳能光伏板

![高性能太阳能光伏板](https://www.saonon.com/vancheerfile/images/2023/7/20230706173045083.jpg)

- 公司简介

- 发展理念

- 公司荣誉

- 销售网络

- 公司动态

- 国内案例

- 国外案例

- 售后服务

- 租赁服务

- 零部件供应

- 下载中心

- 威能视频

![](https://www.saonon.com/image/img475.png)

- 微电网系统

- 光储充系统

- 户用储能系统

当前位置： >

首页

户用储能系统

![](https://www.saonon.com/vancheerfile/images/2024/4/20240423111036844.jpg)

## 堆叠式电池

户用储能系统

SLFP家庭储能电池系列提供高压堆叠和低压堆叠两种选择，用户可自由搭配电池容 量，可拓展性高。采用A级磷酸铁锂电芯，循环次数超过6000次，内置BMS保护电 池安全，支持RS485/RS232/CAN通讯，并可与市场上各种不同型号的储能逆变器兼 容，充分满足用户的多样化需求。

在线咨询

- 照片

- 360度视图

![](https://www.saonon.com/vancheerfile/images/2024/4/20240423111036844.jpg)

- 产品特点

A品电芯

安全性高，循环寿命长，环保

用户友好

设计简单易用，触摸屏幕.。

深度定制

可以通过易于扩展和定制来满足特定需求。

并联操作

支持多个电池并联。

![](https://www.saonon.com/vancheerfile/Images/2024/5/2024051604189647.jpg)

![](https://www.saonon.com/vancheerfile/Images/2024/5/20240516042149608.jpg)

- 产品中心 租赁产品 电气控制系统 柴油发电机组

- 关于威能 公司简介 发展理念 公司荣誉 销售网络 公司动态

- 业务分类 品牌营销 国际分销 国际租赁 项目维持

- 成功案例 国内案例 国外案例

- 服务支持 售后服务 租赁服务 零部件供应 下载中心 威能视频

- 联系威能

## 联系我们

地址：广东省广州市番禺区丽骏路23号 电话： 邮箱： info@saonon.com

020-84666588 400 0063 000

销售服务热线：

售后服务热线：

威能机电公众号

友情链接

Copyright © 广州威能机电有限公司.

粤ICP备2022039524号

Powered by vancheer
