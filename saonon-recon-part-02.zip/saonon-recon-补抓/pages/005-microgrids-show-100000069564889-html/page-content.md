# CMS综合管理系统

> https://www.saonon.com/microgrids/show_100000069564889.html

- 首页

- 发电机组

- 微电网

- 关于威能

- 成功案例

- 服务支持

- 联系威能

- 柴油发电机组

- 电气控制系统

- 租赁产品

- 开架型发电机组

- 静音型发电机组

- 集装箱发电机组

- 便携式小型发电机组

- 移动发电机组

- 低噪音电站

- 康明斯系列

![康明斯系列](https://www.saonon.com/vancheerfile/images/2019/3/20190320025217458.jpg)

- 铂金斯系列

![铂金斯系列](https://www.saonon.com/vancheerfile/images/2019/6/20190621113434651.png)

- 高压发电机组

![高压发电机组](https://www.saonon.com/vancheerfile/images/2019/6/20190628103953612.jpg)

- 玉柴系列

![玉柴系列](https://www.saonon.com/vancheerfile/images/2019/6/20190621112631964.png)

- 产品

- 解决方案

- 微电网系统

- 光储充系统

- 户用储能系统

- 一体化微电网系统

![一体化微电网系统](https://www.saonon.com/vancheerfile/images/2025/6/20250610101739852.jpg)

- 20尺集装箱储能系统

![20尺集装箱储能系统](https://www.saonon.com/vancheerfile/images/2024/7/20240709152545371.jpg)

- 10尺集装箱储能系统

![10尺集装箱储能系统](https://www.saonon.com/vancheerfile/images/2024/7/20240709152733980.jpg)

- 户外柜工商业储能系统

![户外柜工商业储能系统](https://www.saonon.com/vancheerfile/images/2024/7/2024070915295871.jpg)

- CMS综合管理系统

![CMS综合管理系统](https://www.saonon.com/vancheerfile/images/2024/7/2024070915307572.jpg)

- 风力发电机

![风力发电机](https://www.saonon.com/vancheerfile/images/2023/7/20230707094420776.jpg)

- 智能光伏逆变器

![智能光伏逆变器](https://www.saonon.com/vancheerfile/images/2024/7/20240709154021479.jpg)

- 高性能太阳能光伏板

![高性能太阳能光伏板](https://www.saonon.com/vancheerfile/images/2023/7/20230706173045083.jpg)

- 公司简介

- 发展理念

- 公司荣誉

- 销售网络

- 公司动态

- 国内案例

- 国外案例

- 售后服务

- 租赁服务

- 零部件供应

- 下载中心

- 威能视频

![](https://www.saonon.com/image/img475.png)

- 微电网系统

- 光储充系统

- 户用储能系统

当前位置： >

首页

微电网系统

![](https://www.saonon.com/vancheerfile/images/2024/7/20240709153848243.jpg)

![](https://www.saonon.com/vancheerfile/images/2023/7/20230707095151851.jpg)

![](https://www.saonon.com/vancheerfile/images/2024/7/20240709153019910.jpg)

![](https://www.saonon.com/vancheerfile/images/2024/7/20240709153848243.jpg)

![](https://www.saonon.com/vancheerfile/images/2023/7/20230707095151851.jpg)

## CMS综合管理系统

微电网系统

威能自主研发的CMS(Comprehensive Management System)是微电网的信息枢纽和指挥员，对微电网的各个设备进行数据采集、策略运行、功能控制、模型分析及设备状态等综合数据管理。

在线咨询

- 照片

- 360度视图

![](https://www.saonon.com/vancheerfile/images/2023/7/20230707095151851.jpg)

![](https://www.saonon.com/vancheerfile/images/2024/7/20240709153019910.jpg)

- 产品特点

威能自主研发的CMS(Comprehensive Management System)是微电网的信息枢纽和指挥员，对微电网的各个设备进行数据采集、策略运行、功能控制、模型分析及设备状态等综合数据管理。CMS监测和控制光伏发电、电池储能、发电机组、风力发电、充电桩和辅助设备等电站能源设备，以实现多种能源互补，最大化利用可再生能源，降低发电成本，减少碳排放。

![](https://www.saonon.com/vancheerfile/Images/2024/5/20240516024622848.png)

系统优势

威能CMS采用最先进、应用最广泛的C/S 主从分布式体系结构，嵌入式微机服务器支撑系统可靠和稳定运行。

- 统一管理：主站集中控制的分布式管理解决方案，兼容 PV Inverter、PCS、BMS、GenSet和充电桩等众多主流品牌

- 电力优化：平滑可再生能源与发电机组输出功率，最大化利用光伏、风力发电和储能系统能源

- 智能运维：智能策略控制，自动调整光伏、风力发电和储能系统功率，毫秒级响应突变负荷的能力

- 数据洞察：数据实时自动保存，兼具数据管理和趋势图表分析功能，具有完整的监测和保护、操作和记录保存，报表输出便于用户管理

![](https://www.saonon.com/vancheerfile/Images/2024/5/20240516024728411.png)

![](https://www.saonon.com/vancheerfile/Images/2024/5/20240516024724489.png)

![](https://www.saonon.com/vancheerfile/Images/2024/5/20240516024726223.png)

- 产品中心 租赁产品 电气控制系统 柴油发电机组

- 关于威能 公司简介 发展理念 公司荣誉 销售网络 公司动态

- 业务分类 品牌营销 国际分销 国际租赁 项目维持

- 成功案例 国内案例 国外案例

- 服务支持 售后服务 租赁服务 零部件供应 下载中心 威能视频

- 联系威能

## 联系我们

地址：广东省广州市番禺区丽骏路23号 电话： 邮箱： info@saonon.com

020-84666588 400 0063 000

销售服务热线：

售后服务热线：

威能机电公众号

友情链接

Copyright © 广州威能机电有限公司.

粤ICP备2022039524号

Powered by vancheer
