# 智能光伏逆变器

> https://www.saonon.com/microgrids/show_100000065363546.html

- 首页

- 发电机组

- 微电网

- 关于威能

- 成功案例

- 服务支持

- 联系威能

- 柴油发电机组

- 电气控制系统

- 租赁产品

- 开架型发电机组

- 静音型发电机组

- 集装箱发电机组

- 便携式小型发电机组

- 移动发电机组

- 低噪音电站

- 康明斯系列

![康明斯系列](https://www.saonon.com/vancheerfile/images/2019/3/20190320025217458.jpg)

- 铂金斯系列

![铂金斯系列](https://www.saonon.com/vancheerfile/images/2019/6/20190621113434651.png)

- 高压发电机组

![高压发电机组](https://www.saonon.com/vancheerfile/images/2019/6/20190628103953612.jpg)

- 玉柴系列

![玉柴系列](https://www.saonon.com/vancheerfile/images/2019/6/20190621112631964.png)

- 产品

- 解决方案

- 微电网系统

- 光储充系统

- 户用储能系统

- 一体化微电网系统

![一体化微电网系统](https://www.saonon.com/vancheerfile/images/2025/6/20250610101739852.jpg)

- 20尺集装箱储能系统

![20尺集装箱储能系统](https://www.saonon.com/vancheerfile/images/2024/7/20240709152545371.jpg)

- 10尺集装箱储能系统

![10尺集装箱储能系统](https://www.saonon.com/vancheerfile/images/2024/7/20240709152733980.jpg)

- 户外柜工商业储能系统

![户外柜工商业储能系统](https://www.saonon.com/vancheerfile/images/2024/7/2024070915295871.jpg)

- CMS综合管理系统

![CMS综合管理系统](https://www.saonon.com/vancheerfile/images/2024/7/2024070915307572.jpg)

- 风力发电机

![风力发电机](https://www.saonon.com/vancheerfile/images/2023/7/20230707094420776.jpg)

- 智能光伏逆变器

![智能光伏逆变器](https://www.saonon.com/vancheerfile/images/2024/7/20240709154021479.jpg)

- 高性能太阳能光伏板

![高性能太阳能光伏板](https://www.saonon.com/vancheerfile/images/2023/7/20230706173045083.jpg)

- 公司简介

- 发展理念

- 公司荣誉

- 销售网络

- 公司动态

- 国内案例

- 国外案例

- 售后服务

- 租赁服务

- 零部件供应

- 下载中心

- 威能视频

![](https://www.saonon.com/image/img475.png)

- 微电网系统

- 光储充系统

- 户用储能系统

当前位置： >

首页

微电网系统

![](https://www.saonon.com/vancheerfile/images/2024/7/20240709154028729.jpg)

## 智能光伏逆变器

微电网系统

在线咨询

- 照片

- 360度视图

- 产品特点

产品特点

-直流超配1.5倍

-交直流二级防雷

-宽电池电压范围

-先进主动孤岛保护技术

-功率因素超前滞后可调

-直流极性反接保护

-交流短路保护

-接地故障监测、残余电流监测

-组串状态检测、电弧故障检测

-夜间超低功率自耗电＜1W

-通讯接口：USB/RS485/WIFI/4G/LAN/GRPS

-满足并网+安规+EMC、NB/T32004-2013，IEC/EN62109-1&2、EN61000-6-2&4等多种认证与许可

产品优势：

-多路MPPT，可根据应用场景配置

-转换效率超过98.8%，有效提升发电量

-高防护等级，适应高温、高湿、风沙、盐雾等各种复杂环境

- 产品中心 租赁产品 电气控制系统 柴油发电机组

- 关于威能 公司简介 发展理念 公司荣誉 销售网络 公司动态

- 业务分类 品牌营销 国际分销 国际租赁 项目维持

- 成功案例 国内案例 国外案例

- 服务支持 售后服务 租赁服务 零部件供应 下载中心 威能视频

- 联系威能

## 联系我们

地址：广东省广州市番禺区丽骏路23号 电话： 邮箱： info@saonon.com

020-84666588 400 0063 000

销售服务热线：

售后服务热线：

威能机电公众号

友情链接

Copyright © 广州威能机电有限公司.

粤ICP备2022039524号

Powered by vancheer
