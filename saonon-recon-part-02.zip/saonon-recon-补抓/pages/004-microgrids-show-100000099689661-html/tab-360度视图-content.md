# 广州威能一体化微电网系统

> https://www.saonon.com/microgrids/show_100000099689661.html

- 首页

- 发电机组

- 微电网

- 关于威能

- 成功案例

- 服务支持

- 联系威能

- 柴油发电机组

- 电气控制系统

- 租赁产品

- 开架型发电机组

- 静音型发电机组

- 集装箱发电机组

- 便携式小型发电机组

- 移动发电机组

- 低噪音电站

- 康明斯系列

![康明斯系列](https://www.saonon.com/vancheerfile/images/2019/3/20190320025217458.jpg)

- 铂金斯系列

![铂金斯系列](https://www.saonon.com/vancheerfile/images/2019/6/20190621113434651.png)

- 高压发电机组

![高压发电机组](https://www.saonon.com/vancheerfile/images/2019/6/20190628103953612.jpg)

- 玉柴系列

![玉柴系列](https://www.saonon.com/vancheerfile/images/2019/6/20190621112631964.png)

- 产品

- 解决方案

- 微电网系统

- 光储充系统

- 户用储能系统

- 一体化微电网系统

![一体化微电网系统](https://www.saonon.com/vancheerfile/images/2025/6/20250610101739852.jpg)

- 20尺集装箱储能系统

![20尺集装箱储能系统](https://www.saonon.com/vancheerfile/images/2024/7/20240709152545371.jpg)

- 10尺集装箱储能系统

![10尺集装箱储能系统](https://www.saonon.com/vancheerfile/images/2024/7/20240709152733980.jpg)

- 户外柜工商业储能系统

![户外柜工商业储能系统](https://www.saonon.com/vancheerfile/images/2024/7/2024070915295871.jpg)

- CMS综合管理系统

![CMS综合管理系统](https://www.saonon.com/vancheerfile/images/2024/7/2024070915307572.jpg)

- 风力发电机

![风力发电机](https://www.saonon.com/vancheerfile/images/2023/7/20230707094420776.jpg)

- 智能光伏逆变器

![智能光伏逆变器](https://www.saonon.com/vancheerfile/images/2024/7/20240709154021479.jpg)

- 高性能太阳能光伏板

![高性能太阳能光伏板](https://www.saonon.com/vancheerfile/images/2023/7/20230706173045083.jpg)

- 公司简介

- 发展理念

- 公司荣誉

- 销售网络

- 公司动态

- 国内案例

- 国外案例

- 售后服务

- 租赁服务

- 零部件供应

- 下载中心

- 威能视频

![](https://www.saonon.com/image/img475.png)

- 微电网系统

- 光储充系统

- 户用储能系统

当前位置： >

首页

微电网系统

![](https://www.saonon.com/vancheerfile/images/2025/6/20250610101829118.jpg)

![](https://www.saonon.com/vancheerfile/images/2025/6/20250610101749118.jpg)

![](https://www.saonon.com/vancheerfile/images/2025/6/2025061010182258.jpg)

![](https://www.saonon.com/vancheerfile/images/2025/6/20250610101818118.jpg)

![](https://www.saonon.com/vancheerfile/images/2025/6/20250610101829118.jpg)

![](https://www.saonon.com/vancheerfile/images/2025/6/20250610101749118.jpg)

## 一体化微电网系统

微电网系统

MG系列是广州威能自主开发的高度集成、多能互补、不间断供电小型微电网系统。系统将光储一体柜、静音型柴油发电机组集成在公共底盘上，便于安装与运输，可扩展性强，搭配威能自主研发的CMS能量管理系统实时监控微电网运行状况，实现多种能源功率分配与管理。适用于主用电源、负荷平滑、削峰填谷、小型海岛微电网、农场、别墅等多种场景，满足不同用户的需求。

在线咨询

- 照片

- 360度视图

![](https://www.saonon.com/vancheerfile/images/2025/6/2025061010182258.jpg)

![](https://www.saonon.com/vancheerfile/images/2025/6/20250610101818118.jpg)

![](https://www.saonon.com/vancheerfile/images/2025/6/20250610101829118.jpg)

- 产品特点

# MG系列一体化微电网系统

MG系列是广州威能自主开发的高度集成、多能互补、不间断供电小型微电网系统。系统将光储一体柜、静音型柴油发电机组集成在公共底盘上，便于安装与运输，可扩展性强，搭配威能自主研发的CMS能量管理系统实时监控微电网运行状况，实现多种能源功率分配与管理。适用于主用电源、负荷平滑、削峰填谷、小型海岛微电网、农场、别墅等多种场景，满足不同用户的需求。

特点

高效、绿色

- 多路MPPT输入，支持高功率光伏组件；

- 支持多机并网、离网运行，方便扩容；

- 智能功率管理，优先利用光伏、风能等新能源，柴发工作在最佳经济运行点。

安全可靠

- 标配STS模块，系统自动并离网切换时间≤20ms；

- 可选配ATS模块，实现市电与柴油发电机组自动切换，自动补能接入，保证系统持续供电；

- 电池PACK级与电池仓级双重消防，及时、准确发现与消除火灾危险；

- 搭配工业级散热空调或液冷热管理系统，维持电芯最佳工作温度，延长电池寿命。

安装便捷

- 系统集成于公共底盘（选配）上，方便运输、安装；

- 预留负载、光伏、柴油发电机等快速接口，实现快速组网；

- 出厂已预设CMS能量管理系统，系统即开即用。

![](https://www.saonon.com/vancheerfile/Images/2025/6/20250610101926977.png)

![](https://www.saonon.com/vancheerfile/Images/2025/6/20250610101957805.jpg)

- 产品中心 租赁产品 电气控制系统 柴油发电机组

- 关于威能 公司简介 发展理念 公司荣誉 销售网络 公司动态

- 业务分类 品牌营销 国际分销 国际租赁 项目维持

- 成功案例 国内案例 国外案例

- 服务支持 售后服务 租赁服务 零部件供应 下载中心 威能视频

- 联系威能

## 联系我们

地址：广东省广州市番禺区丽骏路23号 电话： 邮箱： info@saonon.com

020-84666588 400 0063 000

销售服务热线：

售后服务热线：

威能机电公众号

友情链接

Copyright © 广州威能机电有限公司.

粤ICP备2022039524号

Powered by vancheer
